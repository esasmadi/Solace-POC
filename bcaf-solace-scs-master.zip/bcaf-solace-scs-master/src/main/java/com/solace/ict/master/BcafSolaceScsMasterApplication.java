package com.solace.ict.master;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BcafSolaceScsMasterApplication {

	public static void main(String[] args) {
		SpringApplication.run(BcafSolaceScsMasterApplication.class, args);
	}

}
