package com.solace.ict.master;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BcafSolaceScsMasterApplicationTests {

	@Test
	void contextLoads() {
	}

}
